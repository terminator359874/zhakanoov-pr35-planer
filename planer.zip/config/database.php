<?php
class Database {
    private $host = 'sql206.infinityfree.com';
    private $db_name = 'if0_41833696_task_manager';  // <-- ЗАМЕНИТЬ
    private $username = 'if0_41833696';
    private $password = '6mCajQm1w6E77';           // <-- ЗАМЕНИТЬ
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                'mysql:host=' . $this->host
                . ';dbname=' . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );
            $this->conn->exec('SET NAMES utf8');
        } catch(PDOException $e) {
            echo 'Ошибка: ' . $e->getMessage();
        }
        return $this->conn;
    }
    
}
